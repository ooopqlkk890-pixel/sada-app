import 'package:flutter/material.dart';
import '../core/logo.dart';
import '../core/theme.dart';
import '../services/auth_service.dart';
import 'home_shell.dart';
import 'login_screen.dart';

/// شاشة افتتاحية متحركة أثناء الدخول التلقائي
class SplashGate extends StatefulWidget {
  const SplashGate({super.key});
  @override
  State<SplashGate> createState() => _SplashGateState();
}

class _SplashGateState extends State<SplashGate> with SingleTickerProviderStateMixin {
  late final AnimationController _a =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 1400))..forward();
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    Future.wait([auth.autoLogin(), Future.delayed(const Duration(milliseconds: 2000))])
        .then((_) => mounted ? setState(() => _ready = true) : null);
  }

  @override
  void dispose() {
    _a.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_ready) {
      return ListenableBuilder(listenable: auth, builder: (_, __) => auth.loggedIn ? const HomeShell() : const LoginScreen());
    }
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
            gradient: RadialGradient(radius: 1.1, colors: [Color(0xFF2A0F4D), SadaColors.bg])),
        child: Center(
          child: FadeTransition(
            opacity: CurvedAnimation(parent: _a, curve: Curves.easeOut),
            child: ScaleTransition(
              scale: Tween(begin: 0.8, end: 1.0).animate(CurvedAnimation(parent: _a, curve: Curves.easeOutBack)),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                const SadaLogo(size: 72),
                const SizedBox(height: 16),
                const Text('عالمك من البث المباشر', style: TextStyle(color: Colors.white54)),
                const SizedBox(height: 32),
                const SizedBox(width: 28, height: 28, child: CircularProgressIndicator(strokeWidth: 2, color: SadaColors.cyan)),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}
