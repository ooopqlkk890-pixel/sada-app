import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import '../core/config.dart';
import '../core/theme.dart';
import '../services/auth_service.dart';
import '../services/favorites_service.dart';
import '../services/xtream_api.dart';
import 'player_screen.dart';

class MovieScreen extends StatelessWidget {
  final MediaItem movie;
  const MovieScreen({super.key, required this.movie});

  String _backdrop(Map<String, dynamic> i) {
    final b = i['backdrop_path'];
    if (b is List && b.isNotEmpty) return '${b.first}';
    return b is String ? b : '';
  }

  void _play(BuildContext context) {
    final c = auth.creds!;
    final hosts = [c.host, ...AppConfig.backupHosts];
    Navigator.push(context, MaterialPageRoute(
      builder: (_) => PlayerScreen(
        title: movie.name,
        isLive: false,
        servers: hosts.map((h) => XtreamApi.streamUrl(h, c, movie)).toList(),
      ),
    ));
  }

  Widget _chip(String t, {Color color = Colors.white70}) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        decoration: BoxDecoration(border: Border.all(color: color.withOpacity(0.5)), borderRadius: BorderRadius.circular(20)),
        child: Text(t, style: TextStyle(fontSize: 12, color: color)),
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        body: FutureBuilder<Map<String, dynamic>>(
          future: auth.api.vodInfo(movie.id).catchError((_) => <String, dynamic>{}),
          builder: (_, s) {
            final info = s.data ?? {};
            final bd = _backdrop(info).isNotEmpty ? _backdrop(info) : movie.icon;
            final rating = '${info['rating'] ?? ''}';
            final plot = '${info['plot'] ?? info['description'] ?? ''}';
            return CustomScrollView(slivers: [
              SliverAppBar(
                expandedHeight: 300, pinned: true, backgroundColor: SadaColors.bg,
                flexibleSpace: FlexibleSpaceBar(
                  background: Stack(fit: StackFit.expand, children: [
                    if (bd.isNotEmpty) CachedNetworkImage(imageUrl: bd, fit: BoxFit.cover, errorWidget: (_, __, ___) => const SizedBox()),
                    const DecoratedBox(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter,
                            colors: [Colors.transparent, SadaColors.bg]),
                      ),
                    ),
                  ]),
                ),
              ),
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(movie.name, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 12),
                    Wrap(spacing: 8, runSpacing: 8, children: [
                      if (rating.isNotEmpty && rating != '0') _chip('★ $rating', color: SadaColors.gold),
                      if ('${info['genre'] ?? ''}'.isNotEmpty) _chip('${info['genre']}', color: SadaColors.cyan),
                      if ('${info['duration'] ?? ''}'.isNotEmpty) _chip('${info['duration']}'),
                      if ('${info['releasedate'] ?? ''}'.isNotEmpty) _chip('${info['releasedate']}'.split('-').first),
                    ]),
                    const SizedBox(height: 20),
                    Row(children: [
                      Expanded(
                        child: SizedBox(
                          height: 52,
                          child: DecoratedBox(
                            decoration: BoxDecoration(
                              gradient: const LinearGradient(colors: [SadaColors.neon, SadaColors.violet]),
                              borderRadius: BorderRadius.circular(14),
                              boxShadow: [BoxShadow(color: SadaColors.neon.withOpacity(0.4), blurRadius: 18)],
                            ),
                            child: TextButton.icon(
                              autofocus: true,
                              onPressed: () => _play(context),
                              icon: const Icon(Icons.play_arrow_rounded, color: Colors.white, size: 28),
                              label: const Text('تشغيل', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      ListenableBuilder(
                        listenable: favorites,
                        builder: (_, __) => IconButton.outlined(
                          iconSize: 28,
                          onPressed: () => favorites.toggle(movie),
                          icon: Icon(favorites.isFav(movie) ? Icons.favorite : Icons.favorite_border,
                              color: favorites.isFav(movie) ? SadaColors.neon : Colors.white),
                        ),
                      ),
                    ]),
                    const SizedBox(height: 24),
                    if (s.connectionState != ConnectionState.done)
                      const Center(child: CircularProgressIndicator())
                    else if (plot.isNotEmpty) ...[
                      const Text('القصة', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: SadaColors.cyan)),
                      const SizedBox(height: 8),
                      Text(plot, style: const TextStyle(height: 1.7, color: Colors.white70)),
                    ],
                    if ('${info['cast'] ?? ''}'.isNotEmpty) ...[
                      const SizedBox(height: 16),
                      Text('الأبطال: ${info['cast']}', style: const TextStyle(color: Colors.white60, fontSize: 13)),
                    ],
                    if ('${info['director'] ?? ''}'.isNotEmpty)
                      Text('الإخراج: ${info['director']}', style: const TextStyle(color: Colors.white60, fontSize: 13)),
                  ]),
                ),
              ),
            ]);
          },
        ),
      );
}
