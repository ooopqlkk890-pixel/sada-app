import 'package:flutter/material.dart';
import '../core/config.dart';
import '../core/theme.dart';
import '../services/auth_service.dart';
import '../services/xtream_api.dart';
import 'player_screen.dart';

class SeriesScreen extends StatefulWidget {
  final MediaItem series;
  const SeriesScreen({super.key, required this.series});
  @override
  State<SeriesScreen> createState() => _SeriesScreenState();
}

class _SeriesScreenState extends State<SeriesScreen> {
  late final Future<Map<int, List<Episode>>> _f = auth.api.seriesEpisodes(widget.series.id);
  int? _season;

  void _play(Episode e) {
    final c = auth.creds!;
    final hosts = [c.host, ...AppConfig.backupHosts];
    Navigator.push(context, MaterialPageRoute(
      builder: (_) => PlayerScreen(
        title: '${widget.series.name} - م${e.season} ح${e.number}',
        isLive: false,
        servers: hosts.map((h) => XtreamApi.episodeUrl(h, c, e)).toList(),
      ),
    ));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(widget.series.name)),
        body: FutureBuilder<Map<int, List<Episode>>>(
          future: _f,
          builder: (_, s) {
            if (s.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
            if (s.hasError || s.data!.isEmpty) return const Center(child: Text('لا توجد حلقات متاحة'));
            final seasons = s.data!.keys.toList()..sort();
            final cur = _season ?? seasons.first;
            return Column(children: [
              SizedBox(
                height: 56,
                child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.all(8), children: [
                  for (final n in seasons)
                    Padding(
                      padding: const EdgeInsetsDirectional.only(end: 8),
                      child: ChoiceChip(label: Text('الموسم $n'), selected: n == cur, selectedColor: SadaColors.neon, onSelected: (_) => setState(() => _season = n)),
                    ),
                ]),
              ),
              Expanded(
                child: ListView.builder(
                  itemCount: s.data![cur]!.length,
                  itemBuilder: (_, i) {
                    final e = s.data![cur]![i];
                    return ListTile(
                      leading: CircleAvatar(backgroundColor: SadaColors.card, child: Text('${e.number}')),
                      title: Text(e.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                      trailing: const Icon(Icons.play_circle_fill_rounded, color: SadaColors.cyan),
                      onTap: () => _play(e),
                    );
                  },
                ),
              ),
            ]);
          },
        ),
      );
}
