import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import '../core/config.dart';
import '../core/logo.dart';
import '../core/theme.dart';
import '../services/auth_service.dart';
import '../services/favorites_service.dart';
import '../services/xtream_api.dart';
import 'player_screen.dart';
import 'series_screen.dart';
import 'movie_screen.dart';

const _tabs = [
  (Icons.sensors_rounded, Icons.sensors_rounded, 'بث مباشر'),
  (Icons.video_library_outlined, Icons.video_library_rounded, 'مسلسلات'),
  (Icons.movie_creation_outlined, Icons.movie_creation_rounded, 'أفلام'),
];

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _i = 0;
  late final _live = auth.api.live(), _movies = auth.api.movies(), _series = auth.api.series();

  @override
  void initState() {
    super.initState();
    favorites.load();
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      _Section(future: _live, wide: true),
      _Section(future: _series),
      _Section(future: _movies),
    ];
    final tv = MediaQuery.of(context).size.width >= 900; // تلفاز/تابلت: شريط جانبي
    final body = Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        title: const SadaLogo(size: 28),
        actions: [
          IconButton(icon: const Icon(Icons.favorite_rounded, color: SadaColors.neon), tooltip: 'المفضلة', onPressed: () => _push(context, 'المفضلة', const _Favs())),
          IconButton(icon: const Icon(Icons.settings_rounded), tooltip: 'الإعدادات', onPressed: () => _push(context, 'الإعدادات', _Settings())),
        ],
      ),
      body: pages[_i],
      bottomNavigationBar: tv
          ? null
          : NavigationBar(
              selectedIndex: _i,
              onDestinationSelected: (v) => setState(() => _i = v),
              destinations: [for (final t in _tabs) NavigationDestination(icon: Icon(t.$1), selectedIcon: Icon(t.$2, color: SadaColors.cyan), label: t.$3)],
            ),
    );
    if (!tv) return body;
    return Row(children: [
      NavigationRail(
        backgroundColor: SadaColors.surface,
        selectedIndex: _i,
        labelType: NavigationRailLabelType.all,
        onDestinationSelected: (v) => setState(() => _i = v),
        destinations: [for (final t in _tabs) NavigationRailDestination(icon: Icon(t.$1), selectedIcon: Icon(t.$2, color: SadaColors.cyan), label: Text(t.$3))],
      ),
      Expanded(child: body),
    ]);
  }
}

void _push(BuildContext c, String title, Widget body) =>
    Navigator.push(c, MaterialPageRoute(builder: (_) => Scaffold(appBar: AppBar(title: Text(title)), body: body)));

class _Favs extends StatelessWidget {
  const _Favs();
  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: favorites,
        builder: (_, __) => favorites.items.isEmpty
            ? const Center(child: Text('لم تضف أي مفضلة بعد'))
            : _Grid(items: favorites.items, wide: false),
      );
}

class _Section extends StatelessWidget {
  final Future<List<MediaItem>> future;
  final bool wide;
  const _Section({required this.future, this.wide = false});
  @override
  Widget build(BuildContext context) => FutureBuilder<List<MediaItem>>(
        future: future,
        builder: (_, s) {
          if (s.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
          if (s.hasError) return Center(child: Text('تعذّر التحميل: ${s.error}'));
          return _Grid(items: s.data!, wide: wide);
        },
      );
}

class _Grid extends StatelessWidget {
  final List<MediaItem> items;
  final bool wide;
  const _Grid({required this.items, required this.wide});
  @override
  Widget build(BuildContext context) => GridView.builder(
        padding: const EdgeInsets.all(12),
        gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
          maxCrossAxisExtent: wide ? 220 : 160,
          childAspectRatio: wide ? 1.4 : 0.62,
          crossAxisSpacing: 10,
          mainAxisSpacing: 10,
        ),
        itemCount: items.length,
        itemBuilder: (_, i) => _Poster(item: items[i]),
      );
}

class _Poster extends StatelessWidget {
  final MediaItem item;
  const _Poster({required this.item});

  void _open(BuildContext context) {
    if (item.type == 'series') {
      Navigator.push(context, MaterialPageRoute(builder: (_) => SeriesScreen(series: item)));
      return;
    }
    if (item.type == 'movie') {
      Navigator.push(context, MaterialPageRoute(builder: (_) => MovieScreen(movie: item)));
      return;
    }
    final c = auth.creds!;
    final hosts = [c.host, ...AppConfig.backupHosts];
    Navigator.push(context, MaterialPageRoute(
      builder: (_) => PlayerScreen(
        title: item.name,
        isLive: item.type == 'live',
        servers: hosts.map((h) => XtreamApi.streamUrl(h, c, item)).toList(),
      ),
    ));
  }

  @override
  Widget build(BuildContext context) => InkWell(
        borderRadius: BorderRadius.circular(14),
        focusColor: SadaColors.neon.withOpacity(0.35), // تمييز العنصر عند التنقل بالريموت
        onTap: () => _open(context),
        onLongPress: () => favorites.toggle(item),
        child: Ink(
          decoration: BoxDecoration(color: SadaColors.card, borderRadius: BorderRadius.circular(14)),
          child: Column(children: [
            Expanded(
              child: Stack(children: [
                Positioned.fill(
                  child: ClipRRect(
                    borderRadius: const BorderRadius.vertical(top: Radius.circular(14)),
                    child: item.icon.isEmpty
                        ? const Center(child: Icon(Icons.image_not_supported_outlined))
                        : CachedNetworkImage(imageUrl: item.icon, fit: BoxFit.cover,
                            errorWidget: (_, __, ___) => const Icon(Icons.broken_image_outlined)),
                  ),
                ),
                PositionedDirectional(
                  top: 4, end: 4,
                  child: ListenableBuilder(
                    listenable: favorites,
                    builder: (_, __) => GestureDetector(
                      onTap: () => favorites.toggle(item),
                      child: CircleAvatar(
                        radius: 14, backgroundColor: Colors.black54,
                        child: Icon(favorites.isFav(item) ? Icons.favorite : Icons.favorite_border,
                            size: 16, color: favorites.isFav(item) ? Colors.redAccent : Colors.white),
                      ),
                    ),
                  ),
                ),
              ]),
            ),
            Padding(
              padding: const EdgeInsets.all(8),
              child: Text(item.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12)),
            ),
          ]),
        ),
      );
}

class _Settings extends StatelessWidget {
  @override
  Widget build(BuildContext context) => ListView(children: [
        ListTile(leading: const Icon(Icons.person), title: Text(auth.creds?.user ?? ''), subtitle: Text('الحالة: ${auth.userInfo?['status'] ?? '-'}')),
        ListTile(leading: const Icon(Icons.logout, color: Colors.redAccent), title: const Text('تسجيل الخروج'), onTap: auth.logout),
      ]);
}
