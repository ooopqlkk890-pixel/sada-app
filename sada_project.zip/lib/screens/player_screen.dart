import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:media_kit/media_kit.dart';
import 'package:media_kit_video/media_kit_video.dart';
import '../core/theme.dart';
import '../services/stream_booster.dart';

class PlayerScreen extends StatefulWidget {
  final String title;
  final List<String> servers;
  final bool isLive;
  const PlayerScreen({super.key, required this.title, required this.servers, required this.isLive});
  @override
  State<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends State<PlayerScreen> {
  late final Player player = Player(configuration: const PlayerConfiguration(bufferSize: 64 * 1024 * 1024));
  late final VideoController controller =
      VideoController(player, configuration: const VideoControllerConfiguration(enableHardwareAcceleration: true));
  late final StreamBooster booster =
      StreamBooster(player: player, servers: widget.servers, isLive: widget.isLive);

  bool _controls = true, _locked = false;
  double _subSize = 30, _volume = 100;

  @override
  void initState() {
    super.initState();
    SystemChrome.setPreferredOrientations([DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    // تسريع العتاد (MediaCodec على أندرويد)
    final p = player.platform;
    if (p is NativePlayer) {
      p.setProperty('hwdec', 'mediacodec,auto-safe');
      p.setProperty('cache', 'yes');
    }
    player.open(Media(widget.servers.first));
    booster.start();
  }

  @override
  void dispose() {
    booster.dispose();
    player.dispose();
    SystemChrome.setPreferredOrientations(DeviceOrientation.values);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  String _fmt(Duration d) {
    String t(int n) => n.toString().padLeft(2, '0');
    return '${d.inHours > 0 ? '${t(d.inHours)}:' : ''}${t(d.inMinutes % 60)}:${t(d.inSeconds % 60)}';
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.black,
        body: Focus(
          autofocus: true,
          onKeyEvent: _onKey,
          child: GestureDetector(
          onTap: () => setState(() => _controls = !_controls),
          child: Stack(children: [
            Video(
              controller: controller,
              controls: NoVideoControls,
              subtitleViewConfiguration: SubtitleViewConfiguration(
                style: TextStyle(fontSize: _subSize, color: Colors.white, backgroundColor: Colors.black54),
              ),
            ),
            StreamBuilder<bool>(
              stream: player.stream.buffering,
              builder: (_, s) => s.data == true
                  ? const Center(child: CircularProgressIndicator(color: SadaColors.cyan))
                  : const SizedBox.shrink(),
            ),
            if (_locked)
              Positioned(
                top: 16, right: 16,
                child: IconButton.filled(icon: const Icon(Icons.lock_open_rounded), onPressed: () => setState(() => _locked = false)),
              )
            else if (_controls) ...[_top(), _bottom()],
          ]),
        )),
      );

  /// تحكم الريموت: OK تشغيل/إيقاف، يمين/يسار تقديم وتأخير، أعلى/أسفل الصوت
  KeyEventResult _onKey(FocusNode n, KeyEvent e) {
    if (e is! KeyDownEvent || _locked) return KeyEventResult.ignored;
    final k = e.logicalKey;
    if (k == LogicalKeyboardKey.select || k == LogicalKeyboardKey.mediaPlayPause) {
      player.playOrPause();
      setState(() => _controls = true);
    } else if (!widget.isLive && k == LogicalKeyboardKey.arrowRight) {
      player.seek(player.state.position + const Duration(seconds: 10));
    } else if (!widget.isLive && k == LogicalKeyboardKey.arrowLeft) {
      player.seek(player.state.position - const Duration(seconds: 10));
    } else if (k == LogicalKeyboardKey.arrowUp || k == LogicalKeyboardKey.arrowDown) {
      setState(() => _volume = (_volume + (k == LogicalKeyboardKey.arrowUp ? 10 : -10)).clamp(0, 100));
      player.setVolume(_volume);
    } else {
      return KeyEventResult.ignored;
    }
    return KeyEventResult.handled;
  }

  Widget _top() => Positioned(
        top: 0, left: 0, right: 0,
        child: Container(
          decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.black87, Colors.transparent])),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          child: Row(children: [
            IconButton(icon: const Icon(Icons.arrow_forward_rounded), onPressed: () => Navigator.pop(context)),
            Expanded(child: Text(widget.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
            ListenableBuilder(
              listenable: booster,
              builder: (_, __) => PopupMenuButton<SadaQuality>(
                icon: const Icon(Icons.high_quality_rounded),
                tooltip: 'الجودة',
                onSelected: booster.setQuality,
                itemBuilder: (_) => [for (final q in SadaQuality.values) CheckedPopupMenuItem(value: q, checked: booster.quality == q, child: Text(qualityLabels[q]!))],
              ),
            ),
            if (widget.servers.length > 1)
              ListenableBuilder(
                listenable: booster,
                builder: (_, __) => PopupMenuButton<int>(
                  icon: const Icon(Icons.dns_rounded),
                  tooltip: 'السيرفر',
                  onSelected: booster.switchServer,
                  itemBuilder: (_) => [for (var i = 0; i < widget.servers.length; i++) CheckedPopupMenuItem(value: i, checked: booster.serverIndex == i, child: Text('سيرفر ${i + 1}'))],
                ),
              ),
            StreamBuilder<Tracks>(
              stream: player.stream.tracks,
              builder: (_, s) {
                final subs = (s.data ?? player.state.tracks).subtitle;
                return PopupMenuButton<SubtitleTrack>(
                  icon: const Icon(Icons.subtitles_rounded),
                  tooltip: 'الترجمة',
                  onSelected: player.setSubtitleTrack,
                  itemBuilder: (_) => [for (final t in subs) PopupMenuItem(value: t, child: Text(t.title ?? t.language ?? t.id))],
                );
              },
            ),
            IconButton(icon: const Icon(Icons.text_increase_rounded), onPressed: () => setState(() => _subSize = (_subSize + 4).clamp(16, 60))),
            IconButton(icon: const Icon(Icons.text_decrease_rounded), onPressed: () => setState(() => _subSize = (_subSize - 4).clamp(16, 60))),
            IconButton(icon: const Icon(Icons.lock_rounded), onPressed: () => setState(() => _locked = true)),
          ]),
        ),
      );

  Widget _bottom() => Positioned(
        bottom: 0, left: 0, right: 0,
        child: Container(
          decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.bottomCenter, end: Alignment.topCenter, colors: [Colors.black87, Colors.transparent])),
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
          child: Row(children: [
            StreamBuilder<bool>(
              stream: player.stream.playing,
              builder: (_, s) => IconButton(iconSize: 36, icon: Icon(s.data == true ? Icons.pause_circle_rounded : Icons.play_circle_rounded), onPressed: player.playOrPause),
            ),
            if (widget.isLive)
              const Expanded(child: Row(children: [Icon(Icons.circle, color: Colors.red, size: 10), SizedBox(width: 6), Text('مباشر')]))
            else
              Expanded(
                child: StreamBuilder<Duration>(
                  stream: player.stream.position,
                  builder: (_, s) {
                    final pos = s.data ?? Duration.zero, dur = player.state.duration;
                    final max = dur.inMilliseconds.toDouble().clamp(1, double.infinity);
                    return Row(children: [
                      Text(_fmt(pos)),
                      Expanded(child: Slider(value: pos.inMilliseconds.toDouble().clamp(0, max), max: max, onChanged: (v) => player.seek(Duration(milliseconds: v.toInt())))),
                      Text(_fmt(dur)),
                    ]);
                  },
                ),
              ),
            const Icon(Icons.volume_up_rounded),
            SizedBox(width: 120, child: Slider(value: _volume, max: 100, onChanged: (v) { setState(() => _volume = v); player.setVolume(v); })),
          ]),
        ),
      );
}
