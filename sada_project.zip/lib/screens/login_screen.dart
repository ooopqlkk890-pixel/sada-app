import 'package:flutter/material.dart';
import '../core/logo.dart';
import '../core/theme.dart';
import '../services/auth_service.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _host = TextEditingController(), _user = TextEditingController(), _pass = TextEditingController();
  bool _useHost = true, _busy = false, _hide = true;
  String? _error;

  Future<void> _submit() async {
    if (_user.text.isEmpty || _pass.text.isEmpty || (_useHost && _host.text.isEmpty)) {
      setState(() => _error = 'أكمل جميع الحقول');
      return;
    }
    setState(() { _busy = true; _error = null; });
    try {
      await auth.login(host: _useHost ? _host.text : null, user: _user.text, pass: _pass.text);
    } catch (e) {
      setState(() => _error = 'تعذّر تسجيل الدخول: ${e.toString().replaceFirst('Exception: ', '')}');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: Container(
          decoration: const BoxDecoration(
            gradient: RadialGradient(center: Alignment(0, -0.8), radius: 1.2,
                colors: [Color(0xFF2A0F4D), SadaColors.bg]),
          ),
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 420),
                child: Column(children: [
                  const SadaLogo(size: 64),
                  const Text('عالمك من البث المباشر', style: TextStyle(color: Colors.white60)),
                  const SizedBox(height: 32),
                  SwitchListTile(
                    value: _useHost,
                    onChanged: (v) => setState(() => _useHost = v),
                    title: const Text('لدي رابط هوست مستقل'),
                    subtitle: Text(_useHost ? 'دخول عبر Xtream Codes' : 'دخول بالاسم وكلمة المرور فقط'),
                  ),
                  if (_useHost) ...[
                    TextField(controller: _host, keyboardType: TextInputType.url, textDirection: TextDirection.ltr,
                        decoration: const InputDecoration(labelText: 'الرابط / الهوست', prefixIcon: Icon(Icons.dns_rounded))),
                    const SizedBox(height: 12),
                  ],
                  TextField(controller: _user, textDirection: TextDirection.ltr,
                      decoration: const InputDecoration(labelText: 'اسم المستخدم', prefixIcon: Icon(Icons.person_rounded))),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _pass, obscureText: _hide, textDirection: TextDirection.ltr,
                    decoration: InputDecoration(
                      labelText: 'كلمة المرور', prefixIcon: const Icon(Icons.lock_rounded),
                      suffixIcon: IconButton(icon: Icon(_hide ? Icons.visibility : Icons.visibility_off),
                          onPressed: () => setState(() => _hide = !_hide)),
                    ),
                    onSubmitted: (_) => _submit(),
                  ),
                  if (_error != null)
                    Padding(padding: const EdgeInsets.only(top: 12), child: Text(_error!, style: const TextStyle(color: Colors.redAccent))),
                  const SizedBox(height: 24),
                  SizedBox(
                    width: double.infinity, height: 52,
                    child: FilledButton(
                      style: FilledButton.styleFrom(backgroundColor: SadaColors.neon, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
                      onPressed: _busy ? null : _submit,
                      child: _busy ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2)) : const Text('دخول إلى صدى', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                    ),
                  ),
                ]),
              ),
            ),
          ),
        ),
      );
}
