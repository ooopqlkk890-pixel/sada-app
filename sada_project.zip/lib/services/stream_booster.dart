import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:media_kit/media_kit.dart';

enum SadaQuality { auto, fhd, hd, sd }

const qualityLabels = {SadaQuality.auto: 'تلقائي', SadaQuality.fhd: 'FHD', SadaQuality.hd: 'HD', SadaQuality.sd: 'SD'};
const _heights = {SadaQuality.auto: 0, SadaQuality.fhd: 1080, SadaQuality.hd: 720, SadaQuality.sd: 480};

/// مُعزّز بث صدى الذكي (خوارزميات تنبؤية خفيفة تعمل على الجهاز):
///  1) تكيّف ذكي: يتوقع هبوط المخزن المؤقت (EWMA + اتجاه) ويخفض الجودة مؤقتاً ثم يعيدها.
///  2) Failover: يراقب التقطّع ويحوّل لأسرع سيرفر بديل بقياس زمن الاستجابة.
class StreamBooster extends ChangeNotifier {
  final Player player;
  final List<String> servers;
  final bool isLive;
  StreamBooster({required this.player, required this.servers, required this.isLive});

  int serverIndex = 0;
  SadaQuality quality = SadaQuality.auto;
  String status = 'البث مستقر';
  double bufferAhead = 0, _ewma = 0, _last = 0;
  bool _degraded = false, _busy = false;
  final _stalls = <DateTime>[];
  Duration _buffered = Duration.zero;
  Timer? _timer;
  final _subs = <StreamSubscription>[];

  void start() {
    _subs.add(player.stream.buffering.listen((b) {
      if (b) _stalls.add(DateTime.now());
    }));
    _subs.add(player.stream.buffer.listen((d) => _buffered = d));
    _timer = Timer.periodic(const Duration(seconds: 1), (_) => _tick());
  }

  Future<void> _tick() async {
    if (_busy) return;
    bufferAhead = ((_buffered - player.state.position).inMilliseconds / 1000).clamp(0, 600).toDouble();
    final trend = bufferAhead - _last;
    _last = bufferAhead;
    _ewma = 0.6 * _ewma + 0.4 * bufferAhead;
    final predicted = _ewma + trend * 3; // توقع بعد 3 ثوانٍ

    _stalls.removeWhere((t) => DateTime.now().difference(t).inSeconds > 30);

    if (quality == SadaQuality.auto) {
      if (!_degraded && predicted < 1.5 && player.state.playing) {
        _degraded = true;
        await _pickHeight(480);
        status = 'الذكاء الاصطناعي خفّض الجودة مؤقتاً لتفادي التوقف';
      } else if (_degraded && _ewma > 8) {
        _degraded = false;
        await player.setVideoTrack(VideoTrack.auto());
        status = 'تمت استعادة الجودة العالية';
      }
    }
    if (_stalls.length >= 3 && servers.length > 1) await _failover();
    notifyListeners();
  }

  Future<void> _pickHeight(int target) async {
    final v = player.state.tracks.video.where((t) => (t.h ?? 0) > 0).toList();
    if (v.isEmpty) return;
    v.sort((a, b) => a.h!.compareTo(b.h!));
    await player.setVideoTrack(v.lastWhere((t) => t.h! <= target, orElse: () => v.first));
  }

  Future<void> setQuality(SadaQuality q) async {
    quality = q;
    _degraded = false;
    q == SadaQuality.auto ? await player.setVideoTrack(VideoTrack.auto()) : await _pickHeight(_heights[q]!);
    notifyListeners();
  }

  Future<int> _ping(String url) async {
    final sw = Stopwatch()..start();
    try {
      await http.head(Uri.parse(url)).timeout(const Duration(seconds: 3));
      return sw.elapsedMilliseconds;
    } catch (_) {
      return 99999;
    }
  }

  Future<void> switchServer(int i) async {
    final pos = player.state.position;
    serverIndex = i;
    await player.open(Media(servers[i]));
    if (!isLive && pos > Duration.zero) await player.seek(pos);
    _stalls.clear();
    status = 'تم التحويل إلى السيرفر ${i + 1}';
    notifyListeners();
  }

  Future<void> _failover() async {
    _busy = true;
    status = 'جارٍ البحث عن أسرع سيرفر بديل...';
    notifyListeners();
    final pings = await Future.wait(servers.map(_ping));
    var best = serverIndex, bestMs = 99999;
    for (var i = 0; i < pings.length; i++) {
      if (i != serverIndex && pings[i] < bestMs) {
        bestMs = pings[i];
        best = i;
      }
    }
    if (best != serverIndex) {
      await switchServer(best);
    } else {
      status = 'لا يوجد سيرفر أفضل حالياً';
      _stalls.clear();
    }
    _busy = false;
  }

  @override
  void dispose() {
    _timer?.cancel();
    for (final s in _subs) {
      s.cancel();
    }
    super.dispose();
  }
}
