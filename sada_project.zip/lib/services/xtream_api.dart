import 'dart:convert';
import 'package:http/http.dart' as http;

class SadaCreds {
  final String host, user, pass;
  const SadaCreds(this.host, this.user, this.pass);
}

class MediaItem {
  final String id, name, icon, type; // live | movie | series
  final String ext;
  MediaItem(this.id, this.name, this.icon, this.type, [this.ext = 'm3u8']);
  String get key => '$type:$id';
  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'icon': icon, 'type': type, 'ext': ext};
  factory MediaItem.fromJson(Map<String, dynamic> j) =>
      MediaItem(j['id'], j['name'], j['icon'], j['type'], j['ext'] ?? 'm3u8');
}

class Episode {
  final String id, title, ext;
  final int season, number;
  Episode(this.id, this.title, this.ext, this.season, this.number);
}

class XtreamApi {
  final SadaCreds c;
  XtreamApi(this.c);

  Uri _u([String? action]) => Uri.parse('${c.host}/player_api.php').replace(queryParameters: {
        'username': c.user,
        'password': c.pass,
        if (action != null) 'action': action,
      });

  Future<dynamic> _get(String? action) async {
    final r = await http.get(_u(action)).timeout(const Duration(seconds: 15));
    if (r.statusCode != 200) throw Exception('خطأ في الخادم (${r.statusCode})');
    return jsonDecode(utf8.decode(r.bodyBytes));
  }

  Future<Map<String, dynamic>> authenticate() async {
    final d = await _get(null);
    final info = d is Map ? d['user_info'] : null;
    if (info == null || '${info['auth']}' != '1') {
      throw Exception('بيانات الدخول غير صحيحة');
    }
    return Map<String, dynamic>.from(info);
  }

  Future<List<MediaItem>> live() async => ((await _get('get_live_streams')) as List)
      .map((e) => MediaItem('${e['stream_id']}', '${e['name']}', '${e['stream_icon'] ?? ''}', 'live'))
      .toList();

  Future<List<MediaItem>> movies() async => ((await _get('get_vod_streams')) as List)
      .map((e) => MediaItem('${e['stream_id']}', '${e['name']}', '${e['stream_icon'] ?? ''}', 'movie',
          '${e['container_extension'] ?? 'mp4'}'))
      .toList();

  Future<List<MediaItem>> series() async => ((await _get('get_series')) as List)
      .map((e) => MediaItem('${e['series_id']}', '${e['name']}', '${e['cover'] ?? ''}', 'series'))
      .toList();

  /// تفاصيل الفيلم (القصة، التقييم، النوع...)
  Future<Map<String, dynamic>> vodInfo(String id) async {
    final uri = _u('get_vod_info').replace(queryParameters: {
      'username': c.user, 'password': c.pass, 'action': 'get_vod_info', 'vod_id': id});
    final r = await http.get(uri).timeout(const Duration(seconds: 15));
    final d = jsonDecode(utf8.decode(r.bodyBytes));
    return Map<String, dynamic>.from((d is Map ? d['info'] : null) ?? {});
  }

  /// حلقات المسلسل مجمّعة حسب الموسم
  Future<Map<int, List<Episode>>> seriesEpisodes(String seriesId) async {
    final uri = _u('get_series_info').replace(queryParameters: {
      'username': c.user, 'password': c.pass, 'action': 'get_series_info', 'series_id': seriesId});
    final r = await http.get(uri).timeout(const Duration(seconds: 15));
    final d = jsonDecode(utf8.decode(r.bodyBytes));
    final raw = d['episodes'];
    final out = <int, List<Episode>>{};
    Iterable<MapEntry<String, dynamic>> entries = raw is Map
        ? raw.entries.map((e) => MapEntry('${e.key}', e.value))
        : (raw as List? ?? []).asMap().entries.map((e) => MapEntry('${e.key + 1}', e.value));
    for (final e in entries) {
      final season = int.tryParse(e.key) ?? 1;
      out[season] = [
        for (final ep in (e.value as List))
          Episode('${ep['id']}', '${ep['title'] ?? 'حلقة'}', '${ep['container_extension'] ?? 'mp4'}',
              season, int.tryParse('${ep['episode_num']}') ?? 0)
      ];
    }
    return out;
  }

  static String episodeUrl(String host, SadaCreds c, Episode e) =>
      '$host/series/${c.user}/${c.pass}/${e.id}.${e.ext}';

  static String streamUrl(String host, SadaCreds c, MediaItem i) => i.type == 'live'
      ? '$host/live/${c.user}/${c.pass}/${i.id}.m3u8'
      : '$host/movie/${c.user}/${c.pass}/${i.id}.${i.ext}';
}
