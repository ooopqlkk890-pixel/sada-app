import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'xtream_api.dart';

class FavoritesService extends ChangeNotifier {
  final Map<String, MediaItem> _items = {};
  List<MediaItem> get items => _items.values.toList();
  bool isFav(MediaItem i) => _items.containsKey(i.key);

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    for (final s in p.getStringList('favs') ?? <String>[]) {
      final i = MediaItem.fromJson(jsonDecode(s));
      _items[i.key] = i;
    }
    notifyListeners();
  }

  Future<void> toggle(MediaItem i) async {
    isFav(i) ? _items.remove(i.key) : _items[i.key] = i;
    notifyListeners();
    final p = await SharedPreferences.getInstance();
    await p.setStringList('favs', _items.values.map((e) => jsonEncode(e.toJson())).toList());
  }
}

final favorites = FavoritesService();
