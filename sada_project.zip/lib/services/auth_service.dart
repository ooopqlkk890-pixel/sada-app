import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../core/config.dart';
import 'xtream_api.dart';

/// دخول مرن: (هوست + مستخدم + كلمة مرور) أو (مستخدم + كلمة مرور فقط)
class AuthService extends ChangeNotifier {
  final _s = const FlutterSecureStorage(aOptions: AndroidOptions(encryptedSharedPreferences: true));
  SadaCreds? creds;
  Map<String, dynamic>? userInfo;

  bool get loggedIn => creds != null;
  XtreamApi get api => XtreamApi(creds!);

  String _normalize(String h) {
    h = h.trim();
    if (!h.startsWith('http')) h = 'http://$h';
    return h.endsWith('/') ? h.substring(0, h.length - 1) : h;
  }

  Future<void> login({String? host, required String user, required String pass}) async {
    final useHost = _normalize((host == null || host.trim().isEmpty) ? AppConfig.defaultHost : host);
    final c = SadaCreds(useHost, user.trim(), pass.trim());
    userInfo = await XtreamApi(c).authenticate();
    creds = c;
    await _s.write(key: 'host', value: c.host);
    await _s.write(key: 'user', value: c.user);
    await _s.write(key: 'pass', value: c.pass);
    notifyListeners();
  }

  Future<bool> autoLogin() async {
    final h = await _s.read(key: 'host'), u = await _s.read(key: 'user'), p = await _s.read(key: 'pass');
    if (h == null || u == null || p == null) return false;
    try {
      await login(host: h, user: u, pass: p);
      return true;
    } catch (_) {
      return false;
    }
  }

  Future<void> logout() async {
    await _s.deleteAll();
    creds = null;
    userInfo = null;
    notifyListeners();
  }
}

final auth = AuthService();
